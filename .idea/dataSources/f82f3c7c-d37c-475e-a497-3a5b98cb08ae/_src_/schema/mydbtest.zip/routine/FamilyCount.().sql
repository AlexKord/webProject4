CREATE PROCEDURE FamilyCount(OUT cnt INT)
  BEGIN
    SELECT count(*) INTO cnt FROM test_table;
  END;
