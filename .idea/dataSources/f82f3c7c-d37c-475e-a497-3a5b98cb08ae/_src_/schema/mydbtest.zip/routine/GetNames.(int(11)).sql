CREATE PROCEDURE GetNames(IN nameId INT)
  BEGIN
    SELECT *FROM test_table WHERE id = nameId;
  END;
